export interface MeldeMst {
    id_mst: number;
    namemst: string;
   
    repraesent:boolean;
   
    
    
}

