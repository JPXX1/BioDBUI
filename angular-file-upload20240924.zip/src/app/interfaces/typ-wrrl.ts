export interface TypWrrl {

    id:number;
    typ:string;
    seefliess:boolean;
    fliess:boolean;
}
