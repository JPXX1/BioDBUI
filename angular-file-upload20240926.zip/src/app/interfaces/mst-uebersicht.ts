export interface MstUebersicht {

    wk: string;
    mst: string;
    komponente:string;
    repreasent:boolean;
    sp1: string;
    sp2: string;
    sp3: string;
    sp4: string;
    sp5: string;
    sp6: string;
    sp7: string;
    sp8: string;
    sp9: string;
    sp10: string;
    sp11: string;
    sp12: string;
    sp13: string;
    sp14: string;
    sp15: string;
}
