export class Taxonzus {id_taxonzus: number;
    importname: string;
    //checked?: Boolean;

   
      
     
    }