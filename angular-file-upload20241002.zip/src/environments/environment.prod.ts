export const environment = {
    production: true,
    apiUrl: 'https://142.93.163.251/api' // Für Produktionsumgebung
   
  };
  export const environmentgeo = {
    production: true,
    geoserverUrl: 'https://142.93.163.251/geoserver'
  };