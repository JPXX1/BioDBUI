import { Component } from '@angular/core';

@Component({
  selector: 'app-monitoringkarte',
  templateUrl: './monitoringkarte.component.html',
  styleUrls: ['./monitoringkarte.component.css']
})
export class MonitoringkarteComponent {

}
