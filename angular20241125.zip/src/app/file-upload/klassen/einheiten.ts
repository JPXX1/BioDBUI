export class Einheiten {id: number;
    importname: string;
    //checked?: Boolean;
}
