import { MessstellenStam } from 'src/app/interfaces/messstellen-stam';

export interface ArraybuendelMstaendern {
    mststam:MessstellenStam[];
    namemst:string;

}
