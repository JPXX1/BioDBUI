export interface Probenehmer {
   
        id_pn: number;
        firma: string;
        adresse: string;
        mail: string;
        telefonnummer: string;
      }
