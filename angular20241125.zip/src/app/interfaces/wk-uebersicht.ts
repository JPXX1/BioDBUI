export interface WkUebersicht {
    idwk:number;
    WKname: string;
    Jahr:number;
    OKZ_TK_MP:string;
    OKZ_TK_Dia:string;
    OKZ_QK_MZB:string;
    OKZ_QK_F:string;
    OKZ_QK_P:string;
    OKZ:string;
   }
