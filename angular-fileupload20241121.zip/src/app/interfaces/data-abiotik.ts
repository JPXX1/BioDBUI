export interface DataAbiotik {
    wk_name: string;
    id_import: number;
    namemst: string;
    id: number;
    id_wk: number;
    parameter: string;
    jahr: string;
    letzte_aenderung: Date;
    einheit: string;
    wert: string;
}