import {WasserkoerperStam} from '../interfaces/wasserkoerper-stam';
import {TypWrrl} from '../interfaces/typ-wrrl';
export interface ArraybuendelWK {

    wkstam:WasserkoerperStam;
    diatyp:TypWrrl[];
    mptyp:TypWrrl[];
    pptyp:TypWrrl[];
    wrrltyp:TypWrrl[];
    gewaesser:TypWrrl[];

}
