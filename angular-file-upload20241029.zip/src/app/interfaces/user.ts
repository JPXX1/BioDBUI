export interface User {
  id_nu?: number;
  vornahme?: string;
  zunahme?: string;
  administrator?: boolean;
  nutzer1?: boolean;
  nutzer2?: boolean;
  nutzer3?: boolean;
  mail?: string;
  id_users?: number;
  login?: string; 
  password?: string;
}
  