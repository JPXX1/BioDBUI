export interface WasserkoerperStam {

    id:number;
    wk_name: string;
    see:boolean;
    kuenstlich:boolean;
    hmwb:boolean;
    bericht_eu:boolean;
    kuerzel: string;
    id_gewaesser:number;
    eu_cd_wb: string;
    land: string;
    updated_at: string;
    wrrl_typ:number;
    mp_typ:number;
    dia_typ:number;
    pp_typ:number;
    pp_typ_str: string;
    dia_typ_str: string;
    wrrl_typ_str: string;
   mp_typ_str: string;
    gewaessername: string;
   
}
