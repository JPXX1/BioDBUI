export interface MstIndex {
    
    mst: string;
        index:number;
    
    
    
}
