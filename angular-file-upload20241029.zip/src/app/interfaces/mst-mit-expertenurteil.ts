export interface MstMitExpertenurteil {
  
        wkName: string;
        id_wk?: number;
        id: number;
        parameter?: string;
        idMst: number;
        namemst: string;
        repraesent?: string;
        idKomp?: number;
        komponente?: string;
        idImport?: number;
        jahr: string;
        letzteAenderung?: string;
        idEinh?: number;
        firma?: string;
        wert: number;
        expertenurteil: string;
        begruendung: string;
        expertenurteilChanged?: Date;
        idNu?: number;
        ausblenden?:boolean;
      }