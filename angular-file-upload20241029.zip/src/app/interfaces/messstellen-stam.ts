export interface MessstellenStam {
  
        id_mst: number;
        namemst: string;
        idgewaesser: number;
        gewaessername:string;
        ortslage: string;
        see:boolean;
        melde_mst:number;
        melde_mst_str:string;
        repraesent:boolean;
        wrrl_typ: number;
        mp_typ: number;
        id_wk: number;
        wk_name:string;
        eu_cd_sm: string;
        dia_typ: number;
        pp_typ: number;
        hw_etrs: number;
        rw_etrs: number;
        updated_at:string;
        // wknamen:[];
        
        
}
