export const environment = {
    production: false,
    apiUrl: 'http://localhost:3000/api' // Für lokale Entwicklung
  };
  export const environmentgeo = {
    production: false,
    geoserverUrl: 'http://localhost:8080/geoserver'
  };