export interface Uebersicht {
        nr:number;
		mst: string;
        anzahl:number;
		sp3: string;
		sp4:string;
		sp5:string;
		sp6:string;
		sp7:string;
        sp8: string;
		sp9: string;
		sp10:string;
		sp11:string;
		sp12:string;
		sp13:string;
        fehler1:string;
        fehler2:string;
        fehler3:string;
		import1:string;
}
